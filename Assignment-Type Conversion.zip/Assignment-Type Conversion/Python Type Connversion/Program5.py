
my_tuple = (7, 9, 3, 1, 5)


my_list = list(my_tuple)


print("Original tuple:", my_tuple)
print("Converted list:", my_list)

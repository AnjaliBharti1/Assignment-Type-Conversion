def int_to_float(num):
    return float(num)


integer_number = 32
float_number = int_to_float(integer_number)
print("Integer number:", integer_number)
print("Float number:", float_number)

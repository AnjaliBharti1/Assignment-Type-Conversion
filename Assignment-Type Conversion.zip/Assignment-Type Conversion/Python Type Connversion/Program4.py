
my_list = [7, 9, 3, 1, 5]


my_tuple = tuple(my_list)

print("Original list:", my_list)
print("Converted tuple:", my_tuple)


integer_number = 32
string_number = str(integer_number)

# Outputs

print("Integer number:", integer_number)
print("String representation:", string_number)
print("Type of string representation:", type(string_number))

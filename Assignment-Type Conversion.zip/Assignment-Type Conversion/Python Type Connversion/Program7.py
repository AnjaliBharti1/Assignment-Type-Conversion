
number = int(input("Enter a non-zero integer number: "))

boolean_value = bool(number)


print("Boolean value of the number:", boolean_value)

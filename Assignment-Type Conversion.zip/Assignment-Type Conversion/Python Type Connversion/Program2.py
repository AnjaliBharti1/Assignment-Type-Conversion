def float_to_int(num):
    return int(num)


float_number = 6.12
integer_number = float_to_int(float_number)
print("Float number:", float_number)
print("Integer number:", integer_number)

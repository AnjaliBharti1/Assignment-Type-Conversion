def decimalToBinary(n): 
    return "{0:b}".format(int(n))
   

if __name__ == '__main__': 
    print(decimalToBinary(8.2)) 
    print(decimalToBinary(18.4)) 
    print(decimalToBinary(7.33)) 